﻿using EduAssess.Data;
using EduAssess.Models.CursoModel;
using EduAssess.Models.TurmaModel;
using EduAssess.Models.UserModel;
using EduAssess.Services;
using Microsoft.EntityFrameworkCore;

namespace EduAssess.Routes.TurmaRoutes
{
    public static class TurmaRoutes
    {
        public static void MapTurmaRoutes(this WebApplication app)
        {
            var route = app.MapGroup("turmas");
            route.MapPost("create",
                async (TurmaRequest req, AppDbContext context) =>
                {
                    if (!MiniValidation.MiniValidator.TryValidate(req, out var errors))
                        return Results.BadRequest(errors);
                    var existingTurma = await context.Turmas.FirstOrDefaultAsync(t => t.Nome == req.nome);
                    if (existingTurma != null)
                        return Results.BadRequest(new { message = "Turma já existente" });
                    var turma = new TurmaModel(req.nome, req.cursoId, req.professorId, 1);
                    await context.Turmas.AddAsync(turma);
                    await context.SaveChangesAsync();
                    return Results.Ok(new { message = "Turma criada com sucesso", turmaId = turma.Id });
                });
            route.MapGet("update",
                async (TurmaRequest req, AppDbContext context) =>
                {
                    if (!MiniValidation.MiniValidator.TryValidate(req, out var errors))
                        return Results.BadRequest(errors);
                    var existingTurma = await context.Turmas.FirstOrDefaultAsync(t => t.Nome == req.nome);
                    if (existingTurma == null)
                        return Results.BadRequest(new
                        {
                            message = "Turma não existente"
                        });
                    var turma = await context.Turmas.FirstOrDefaultAsync(t => t.Nome == req.nome);
                    return Results.Ok(new
                    {
                        message = "Turma Encontrada",
                        turma = new
                        {
                            turma.Id,
                            turma.CursoId,
                            turma.ProfessorId,
                            turma.PeriodoEmSemestre,
                            turma.Ativo,
                        }
                    });
                });
        }
    }
}
